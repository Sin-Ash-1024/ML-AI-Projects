from gym import spaces
import numpy as np
import random
from itertools import groupby
from itertools import product



class TicTacToe:
    def __init__(self):
        # The 3*3 board is represented as an array of 9 values
        # 
        # 0 1 2
        # 3 4 5
        # 6 7 8
        self.board = [0]*9
        
        # initialise state as an array
        self.state = [np.nan for _ in range(9)]  # initialises the board position, can initialise to an array
        # all possible numbers
        self.all_possible_numbers = [i for i in range(1, len(self.state) + 1)] # , can initialise to an array
        
        #Instead of hardcoding the possible values, we will consider 2 set of players 
        
        # Odd player has only options [1, 3, 5, 7, 9]
        self.player1 = None # These values are passed as input to the QLearning process
        # Even player has only options [2, 4, 6, 8]
        self.player2 = None # These values are passed as input to the QLearning process

    #reset the game
    def reset(self):
        self.board = [0] * 9

   #evaluate function
    def is_winning(self):
        # "rows checking"
        # 0->1->2 = 15
        # 3->4->5 = 15
        # 6->7->8 = 15
        for i in range(3):
            if (self.board[i * 3] + self.board[i * 3 + 1] + self.board[i * 3 + 2]) == 15:
                return 1.0, True
        
        # "col checking"
        for i in range(3):
            if (self.board[i + 0] + self.board[i + 3] + self.board[i + 6]) == 15:
                return 1.0, True
        
        # diagonal checking
        if (self.board[0] + self.board[4] + self.board[8]) == 15:
            return 1.0, True
        if (self.board[2] + self.board[4] + self.board[6]) == 15:
            return 1.0, True

        # "if filled draw"
        if not any(space == 0 for space in self.board):
            return 0.0, True

        return 0.0, False
    
    
        """Takes state as an input and returns whether any row, column or diagonal has winning sum
        Example: Input state- [1, 2, 3, 4, nan, nan, nan, nan, nan]
        Output = False"""
        
    def is_terminal(self, curr_state):
        # Terminal state could be winning state or when the board is filled up

        if self.is_winning(curr_state) == True:
            return True, 'Win'

        elif len(self.allowed_positions(curr_state)) ==0:
            return True, 'Tie'

        else:
            return False, 'Resume'    

    #return remaining possible moves
    def possible_moves(self):
        blank_spots =  [moves + 1 for moves, spot in enumerate(self.board) if spot == 0]
        return blank_spots
    
    def allowed_values(self, curr_state):
        """Takes the current state as input and returns all possible (unused) values that can be placed on the board"""

        player1.options = [val for val in curr_state if not np.isnan(val)]
        player1.options = [val for val in self.all_possible_numbers if val not in used_values and val % 2 !=0]
        player2.options = [val for val in self.all_possible_numbers if val not in used_values and val % 2 ==0]

        return (player1.options, player2.options)


    #pick a possible move based on the odd or even player
    def state_transition(self, isX):
        # shuffle the set of remaining options, pop the first from the list to be used for the move.
        # in this setup, one players plays odd numbers and the other player plays even numbers, 
        # so it is required to switch between the two to determine the next move pick
        
        if(isX):
            self.player1.options = random.sample(self.player1.options, len(self.player1.options))
            return self.player1.options.pop()

        else:
            self.player2.options = random.sample(self.player2.options, len(self.player2.options))
            return self.player2.options.pop()
    
                   
        """Takes current state and action and returns the board position just after agent's move.
        Example: Input state- [1, 2, 3, 4, nan, nan, nan, nan, nan], action- [7, 9] or [position, value]
        Output = [1, 2, 3, 4, nan, nan, nan, 9, nan]"""
        
        
    #take next step and return reward
    def step(self, isX, move):   #isX indicative of current state, move indicative of current action
        self.board[move-1]= self.state_transition(isX)
        reward, done = self.is_winning()
        return reward, done
        #"reward" would be 0 or 1. "done" would be True if game is terminal that is, it ends with win/lose/tie. It would be False otherwise.
    
    #begin training
    def startTraining(self, player1, player2, iterations, odd=True, verbose = False):
        self.player1=player1
        self.player2=player2
        print ("Training Started")
        for i in range(iterations):
            if verbose: print("training ", i)
            self.player1.game_begin()
            self.player2.game_begin()
            self.reset()
            done = False

            # Odd player always begins the game for this simulation so, it is set to true by default
            isX = odd
            while not done:
                if isX:
                    move = self.player1.epsilon_greedy(self.board, self.possible_moves())
                else:
                    move = self.player2.epsilon_greedy(self.board, self.possible_moves())

                # Remember that 'reward' value is 0 or 1 and 'done' is True if game ends (win, lose, draw), False otherwise
                
                reward, done = self.step(isX, move)
                   
                # Handling the cases where game is terminal or not
                if (reward == 1):  # decisive Win (for 1 agent, the other loses obviously), reward 10 for the winning agent and -10 to losing agent
                    if (isX):
                        self.player1.updateQ(10, self.board, self.possible_moves())
                        self.player2.updateQ(-10, self.board, self.possible_moves())
                    else:
                        self.player1.updateQ(-10, self.board, self.possible_moves())
                        self.player2.updateQ(10, self.board, self.possible_moves())
                elif (done == False):  # a move was made but game has not ended yet,  reward -1 for the move
                    if (isX):
                        self.player1.updateQ(-1, self.board, self.possible_moves())
                   

                else: #Tie case
                    self.player1.updateQ(reward, self.board, self.possible_moves())
                    self.player2.updateQ(reward, self.board, self.possible_moves())


                isX = not isX  # switching the odd and even agents
        print ("Training Complete")

    #return the Q-tables
    def getQ(self):
        return self.player1.Q, self.player2.Q